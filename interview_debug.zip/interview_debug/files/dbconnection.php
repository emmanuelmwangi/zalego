<?php

define('DB_HOST', '');
define('DB_USER', '');
define('DB_PASS', '');
define('DB_NAME', '');

$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASS,) or die('Connection Error => '.mysqli_connect_error());
